import myMath
a = myMath.penambahan(9, 10)


import myMath
b = myMath.pengurangan(3, 7)


import myMath
c = myMath.perkalian(5, 11)


import myMath
d = myMath.pembagian(5, 5)

print(a, b, c, d)